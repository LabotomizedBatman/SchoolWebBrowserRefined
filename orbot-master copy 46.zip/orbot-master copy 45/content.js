// content.js

// Function to open Google in a new tab
function openGoogle() {
    window.open('https://www.torry.io/', '_blank');
}

// Add event listener to trigger the function when a button is clicked
document.getElementById('viewContentBtn').addEventListener('click', openGoogle);
